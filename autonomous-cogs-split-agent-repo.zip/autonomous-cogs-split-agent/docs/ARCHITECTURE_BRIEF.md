# System Architecture Brief: Autonomous COGS Split & Fulfillment Agent

## 1. Execution Lifecycle

1. **Event Ingestion:** Storefront emits `order.created` webhook containing `order_id`, `payment_intent_id`, `line_items`, and `shipping_address`.
2. **Deterministic Cost Lookup:** Agent invokes `get_supplier_cost_matrix(supplier_id)` to retrieve verified unit COGS, flat/tiered shipping rates, and the supplier's connected payout account ID.
3. **Pre-Execution Margin Validation:**
   - Computes `total_supplier_obligation = (cogs_per_unit * quantity) + shipping_fee`.
   - Computes `merchant_net_profit = checkout_total - total_supplier_obligation`.
   - **Hard Stop:** If `merchant_net_profit <= 0`, payout execution is blocked and an escalation ticket is emitted.
4. **PII Isolation & Parallel Execution:**
   - **Financial Plane (Sanitized):** Calls `execute_split_payout()` with `idempotency_key = f"{order_id}_split"`. No customer name or street address enters the financial payload.
   - **Logistics Plane (PII-Scoped):** Calls `transmit_fulfillment_order()` to push SKU, quantity, and shipping address to the supplier's ERP/EDI endpoint.
5. **Ledger State Commit:** Invokes `update_store_order_status()` with split confirmation IDs and fulfillment tracking references.

---

## 2. Deterministic Tool Surface (4-Tool Boundary)

To eliminate hallucinated API calls and bound inference latency under `< 1.5s`, the agent operates exclusively within a strict 4-tool boundary:

1. `get_supplier_cost_matrix(supplier_id)`
2. `execute_split_payout(payment_intent_id, supplier_account_id, cogs_amount, profit_amount, idempotency_key)`
3. `transmit_fulfillment_order(supplier_id, sanitized_fulfillment_payload)`
4. `update_store_order_status(order_id, status, routing_logs)`

---

## 3. Enterprise Security & Compliance Posture

* **Zero Fund Custody:** Eliminates money-transmitter licensing exposure by executing splits natively via payment processor split APIs (e.g., Stripe Connect Destination Charges / Separate Charges and Transfers, or Adyen for Platforms).
* **Replay Protection:** Deterministic idempotency keys ensure network retries or duplicate webhook deliveries cannot trigger double transfers.
* **Data Minimization:** Enforces strict schema separation between financial routing and 3PL logistics dispatch.
