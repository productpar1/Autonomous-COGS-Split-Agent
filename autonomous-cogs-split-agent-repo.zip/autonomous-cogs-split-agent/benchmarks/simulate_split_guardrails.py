"""
Deterministic Guardrail & Unit Economics Verifier
Autonomous Order Fulfillment & COGS Split Agent
Copyright (c) 2026 Vine Venture Group LLC
"""

import json
import time
from typing import Dict, Any

SUPPLIER_DB = {
    "sup_alpha_99": {
        "cogs_per_unit": 25.00,
        "shipping_flat_fee": 10.00,
        "payout_account_id": "acct_stripe_connect_12345",
        "fulfillment_method": "API_REST",
    }
}


def process_order_event(payload: Dict[str, Any]) -> Dict[str, Any]:
    start_ns = time.perf_counter_ns()
    order_id = payload["order_id"]
    checkout_total = payload["checkout_total"]
    item = payload["line_items"][0]

    supplier = SUPPLIER_DB.get(item["supplier_id"])
    if not supplier:
        return {"order_id": order_id, "status": "ESCALATED_UNKNOWN_SUPPLIER"}

    total_cogs = (supplier["cogs_per_unit"] * item["quantity"]) + supplier["shipping_flat_fee"]
    merchant_profit = round(checkout_total - total_cogs, 2)

    # Guardrail 1: Negative Margin Floor
    if merchant_profit <= 0:
        elapsed_ms = (time.perf_counter_ns() - start_ns) / 1_000_000
        return {
            "order_id": order_id,
            "status": "HALTED_NEGATIVE_MARGIN_FLOOR",
            "checkout_total": checkout_total,
            "calculated_cogs": total_cogs,
            "merchant_profit": merchant_profit,
            "latency_ms": round(elapsed_ms, 3),
        }

    # Guardrail 2: Deterministic Idempotency Key & PII Stripping
    idempotency_key = f"{order_id}_split"
    financial_payload = {
        "payment_intent_id": payload["payment_intent_id"],
        "supplier_account_id": supplier["payout_account_id"],
        "cogs_amount": total_cogs,
        "profit_amount": merchant_profit,
        "idempotency_key": idempotency_key,
    }

    assert "shipping_address" not in financial_payload, "VPC PII Isolation Violation"

    elapsed_ms = (time.perf_counter_ns() - start_ns) / 1_000_000
    return {
        "order_id": order_id,
        "status": "SPLIT_AND_ROUTED",
        "financial_instruction": financial_payload,
        "pii_isolated": True,
        "latency_ms": round(elapsed_ms, 3),
    }


if __name__ == "__main__":
    valid_order = {
        "order_id": "ORD-98421",
        "currency": "USD",
        "checkout_total": 150.00,
        "payment_intent_id": "pi_3MtwB2Lkdlw",
        "line_items": [
            {"sku": "SKU-SUPPLIER-A-01", "quantity": 2, "retail_price": 75.00, "supplier_id": "sup_alpha_99"}
        ],
        "shipping_address": {
            "name": "Jane Doe",
            "street": "123 Main St",
            "city": "Austin",
            "state": "TX",
            "zip": "78701",
        },
    }

    negative_margin_order = {**valid_order, "order_id": "ORD-98422", "checkout_total": 55.00}

    print("--- Test 1: Valid Atomic Split ---")
    print(json.dumps(process_order_event(valid_order), indent=2))
    print("\n--- Test 2: Negative Margin Floor Halt ---")
    print(json.dumps(process_order_event(negative_margin_order), indent=2))
